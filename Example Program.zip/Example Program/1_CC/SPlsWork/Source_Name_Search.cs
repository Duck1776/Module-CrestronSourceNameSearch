using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;
using Crestron;
using Crestron.Logos.SplusLibrary;
using Crestron.Logos.SplusObjects;
using Crestron.SimplSharp;

namespace UserModule_SOURCE_NAME_SEARCH
{
    public class UserModuleClass_SOURCE_NAME_SEARCH : SplusObject
    {
        static CCriticalSection g_criticalSection = new CCriticalSection();
        
        
        
        
        Crestron.Logos.SplusObjects.StringOutput SEARCH_FB__DOLLAR__;
        Crestron.Logos.SplusObjects.StringInput SEARCH__DOLLAR__;
        InOutArray<Crestron.Logos.SplusObjects.StringInput> SOURCETEXT__DOLLAR__;
        InOutArray<Crestron.Logos.SplusObjects.DigitalInput> SOURCEVIS_IN;
        InOutArray<Crestron.Logos.SplusObjects.DigitalOutput> SOURCEVIS_OUT;
        object SEARCH__DOLLAR___OnChange_0 ( Object __EventInfo__ )
        
            { 
            Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
            try
            {
                SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
                ushort X = 0;
                
                ushort Y = 0;
                
                ushort Z = 0;
                
                ushort TEMP = 0;
                
                
                __context__.SourceCodeLine = 36;
                X = (ushort) ( Functions.Length( SEARCH__DOLLAR__ ) ) ; 
                __context__.SourceCodeLine = 37;
                SEARCH_FB__DOLLAR__  .UpdateValue ( SEARCH__DOLLAR__  ) ; 
                __context__.SourceCodeLine = 39;
                ushort __FN_FORSTART_VAL__1 = (ushort) ( 1 ) ;
                ushort __FN_FOREND_VAL__1 = (ushort)500; 
                int __FN_FORSTEP_VAL__1 = (int)1; 
                for ( Y  = __FN_FORSTART_VAL__1; (__FN_FORSTEP_VAL__1 > 0)  ? ( (Y  >= __FN_FORSTART_VAL__1) && (Y  <= __FN_FOREND_VAL__1) ) : ( (Y  <= __FN_FORSTART_VAL__1) && (Y  >= __FN_FOREND_VAL__1) ) ; Y  += (ushort)__FN_FORSTEP_VAL__1) 
                    { 
                    __context__.SourceCodeLine = 40;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (SOURCEVIS_IN[ Y ] .Value == 1))  ) ) 
                        { 
                        __context__.SourceCodeLine = 41;
                        SOURCEVIS_OUT [ Y]  .Value = (ushort) ( 0 ) ; 
                        __context__.SourceCodeLine = 42;
                        Z = (ushort) ( Functions.FindNoCase( SEARCH__DOLLAR__ , SOURCETEXT__DOLLAR__[ Y ] ) ) ; 
                        __context__.SourceCodeLine = 44;
                        if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.BoolToInt ( Z >= 1 ) ) && Functions.TestForTrue ( Functions.BoolToInt ( X > 0 ) )) ))  ) ) 
                            { 
                            __context__.SourceCodeLine = 45;
                            SOURCEVIS_OUT [ Y]  .Value = (ushort) ( 1 ) ; 
                            } 
                        
                        else 
                            {
                            __context__.SourceCodeLine = 47;
                            if ( Functions.TestForTrue  ( ( Functions.BoolToInt (X == 0))  ) ) 
                                { 
                                __context__.SourceCodeLine = 48;
                                SOURCEVIS_OUT [ Y]  .Value = (ushort) ( SOURCEVIS_IN[ Y ] .Value ) ; 
                                } 
                            
                            }
                        
                        } 
                    
                    __context__.SourceCodeLine = 39;
                    } 
                
                
                
            }
            catch(Exception e) { ObjectCatchHandler(e); }
            finally { ObjectFinallyHandler( __SignalEventArg__ ); }
            return this;
            
        }
        
    object SOURCEVIS_IN_OnChange_1 ( Object __EventInfo__ )
    
        { 
        Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
        try
        {
            SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
            ushort X = 0;
            
            
            __context__.SourceCodeLine = 56;
            X = (ushort) ( Functions.GetLastModifiedArrayIndex( __SignalEventArg__ ) ) ; 
            __context__.SourceCodeLine = 58;
            SOURCEVIS_OUT [ X]  .Value = (ushort) ( SOURCEVIS_IN[ X ] .Value ) ; 
            
            
        }
        catch(Exception e) { ObjectCatchHandler(e); }
        finally { ObjectFinallyHandler( __SignalEventArg__ ); }
        return this;
        
    }
    
public override object FunctionMain (  object __obj__ ) 
    { 
    try
    {
        SplusExecutionContext __context__ = SplusFunctionMainStartCode();
        
        
        
    }
    catch(Exception e) { ObjectCatchHandler(e); }
    finally { ObjectFinallyHandler(); }
    return __obj__;
    }
    

public override void LogosSplusInitialize()
{
    SocketInfo __socketinfo__ = new SocketInfo( 1, this );
    InitialParametersClass.ResolveHostName = __socketinfo__.ResolveHostName;
    _SplusNVRAM = new SplusNVRAM( this );
    
    SOURCEVIS_IN = new InOutArray<DigitalInput>( 500, this );
    for( uint i = 0; i < 500; i++ )
    {
        SOURCEVIS_IN[i+1] = new Crestron.Logos.SplusObjects.DigitalInput( SOURCEVIS_IN__DigitalInput__ + i, SOURCEVIS_IN__DigitalInput__, this );
        m_DigitalInputList.Add( SOURCEVIS_IN__DigitalInput__ + i, SOURCEVIS_IN[i+1] );
    }
    
    SOURCEVIS_OUT = new InOutArray<DigitalOutput>( 500, this );
    for( uint i = 0; i < 500; i++ )
    {
        SOURCEVIS_OUT[i+1] = new Crestron.Logos.SplusObjects.DigitalOutput( SOURCEVIS_OUT__DigitalOutput__ + i, this );
        m_DigitalOutputList.Add( SOURCEVIS_OUT__DigitalOutput__ + i, SOURCEVIS_OUT[i+1] );
    }
    
    SEARCH__DOLLAR__ = new Crestron.Logos.SplusObjects.StringInput( SEARCH__DOLLAR____AnalogSerialInput__, 255, this );
    m_StringInputList.Add( SEARCH__DOLLAR____AnalogSerialInput__, SEARCH__DOLLAR__ );
    
    SOURCETEXT__DOLLAR__ = new InOutArray<StringInput>( 500, this );
    for( uint i = 0; i < 500; i++ )
    {
        SOURCETEXT__DOLLAR__[i+1] = new Crestron.Logos.SplusObjects.StringInput( SOURCETEXT__DOLLAR____AnalogSerialInput__ + i, SOURCETEXT__DOLLAR____AnalogSerialInput__, 255, this );
        m_StringInputList.Add( SOURCETEXT__DOLLAR____AnalogSerialInput__ + i, SOURCETEXT__DOLLAR__[i+1] );
    }
    
    SEARCH_FB__DOLLAR__ = new Crestron.Logos.SplusObjects.StringOutput( SEARCH_FB__DOLLAR____AnalogSerialOutput__, this );
    m_StringOutputList.Add( SEARCH_FB__DOLLAR____AnalogSerialOutput__, SEARCH_FB__DOLLAR__ );
    
    
    SEARCH__DOLLAR__.OnSerialChange.Add( new InputChangeHandlerWrapper( SEARCH__DOLLAR___OnChange_0, false ) );
    for( uint i = 0; i < 500; i++ )
        SOURCEVIS_IN[i+1].OnDigitalChange.Add( new InputChangeHandlerWrapper( SOURCEVIS_IN_OnChange_1, false ) );
        
    
    _SplusNVRAM.PopulateCustomAttributeList( true );
    
    NVRAM = _SplusNVRAM;
    
}

public override void LogosSimplSharpInitialize()
{
    
    
}

public UserModuleClass_SOURCE_NAME_SEARCH ( string InstanceName, string ReferenceID, Crestron.Logos.SplusObjects.CrestronStringEncoding nEncodingType ) : base( InstanceName, ReferenceID, nEncodingType ) {}




const uint SEARCH_FB__DOLLAR____AnalogSerialOutput__ = 0;
const uint SEARCH__DOLLAR____AnalogSerialInput__ = 0;
const uint SOURCETEXT__DOLLAR____AnalogSerialInput__ = 1;
const uint SOURCEVIS_IN__DigitalInput__ = 0;
const uint SOURCEVIS_OUT__DigitalOutput__ = 0;

[SplusStructAttribute(-1, true, false)]
public class SplusNVRAM : SplusStructureBase
{

    public SplusNVRAM( SplusObject __caller__ ) : base( __caller__ ) {}
    
    
}

SplusNVRAM _SplusNVRAM = null;

public class __CEvent__ : CEvent
{
    public __CEvent__() {}
    public void Close() { base.Close(); }
    public int Reset() { return base.Reset() ? 1 : 0; }
    public int Set() { return base.Set() ? 1 : 0; }
    public int Wait( int timeOutInMs ) { return base.Wait( timeOutInMs ) ? 1 : 0; }
}
public class __CMutex__ : CMutex
{
    public __CMutex__() {}
    public void Close() { base.Close(); }
    public void ReleaseMutex() { base.ReleaseMutex(); }
    public int WaitForMutex() { return base.WaitForMutex() ? 1 : 0; }
}
 public int IsNull( object obj ){ return (obj == null) ? 1 : 0; }
}


}
